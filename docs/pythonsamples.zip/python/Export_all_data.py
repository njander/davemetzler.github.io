import arcpy, os
from arcpy import env
from arcpy import mapping
'''This script will export all vector data from an mxd to a destination folder'''
mapDoc = # your map document here formatted as r"C:\somefolder\something.mxd
exp = #your destination folder here as r"r"C:\wherethedatagoes
mxd = mapping.MapDocument(mapDoc)
lyrs = mapping.ListLayers(mxd)
lyrTitle = 'Map Layer'
sourceTitle = 'Data Source'
print('%-60s%s' % (lyrTitle,sourceTitle))
print('%-60s%s' % ('-' * len(lyrTitle), '-' * len(sourceTitle)))
for lyr in lyrs:
    try:
        print('%-60s%s' % (lyr.name,lyr.dataSource))
        arcpy.FeatureClassToShapefile_conversion(lyr.dataSource, exp ) 
    except:
        print(lyr.name + 'Unable to retrieve layer information')
del mxd

