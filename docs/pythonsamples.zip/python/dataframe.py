import arcpy
import arcpy.mapping
from arcpy import mapping
'''This bad boy will create a shapefile of the extent of the first data
frame within the mxd. it will then use this shapefile to clip all of
the data within the mxd to the extent of the map'''
#Arcmap parameters used if you are puting this into an arctoolbox
mapdoc = arcpy.GetParameterAsText(0)
folder = arcpy.GetParameterAsText(1)
#end of user parameters
mxd = arcpy.mapping.MapDocument(mapdoc)
df = arcpy.mapping.ListDataFrames(mxd)[0]
lyrs = mapping.ListLayers(mxd)
shp = folder + "\\" + "extent.shp"

#define the extent of the mxd
Feature = arcpy.Polygon(arcpy.Array([df.extent.lowerLeft, df.extent.lowerRight, df.extent.upperRight, df.extent.upperLeft]))
#create extent.shp
arcpy.CopyFeatures_management(Feature, shp)
#defines the projection from mxd
arcpy.DefineProjection_management(shp, df.spatialReference)

#clip all layers to extent.shpt
for lyr in lyrs:
    try:
        arcpy.Clip_analysis(lyr, shp, folder + "\\" + lyr.name)
    except:
        print('I want to clip; but i cannot clip: ' + lyr.name)
del mxd
