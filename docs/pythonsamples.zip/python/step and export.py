import arcpy
"""this script will step through a feature class and export individual shapefiles based on a field you specify. I have found it useful when converting CAD data where there are sometimes 50,000+
features and it is difficult to filter out the junk. keep in mind databases will not accept certain characters in feature class names"""
featureclass = #The feature class you wish to split by attribute
field = "Layer" #the field you would like to use for separation. with CAD files this is usually the LAYER attribute
dest = r"C:\somefolder" #the folder you want the individual files to go. 
valueList = []
rows = arcpy.SearchCursor(featureclass)
for row in rows:
    valueList.append(row.getValue(field))

uniqueSet = set(valueList)
uniqueList = list(uniqueSet)
uniqueList.sort()

del rows
del row
arcpy.MakeFeatureLayer_management(featureclass, "lyr")
print uniqueList
nogo = [".", "/",":", "!","#","&","-"]
for i in uniqueList:
    
    try:
        
        query=  "Layer = " + "'" + i + "'" 
        arcpy.SelectLayerByAttribute_management("lyr", "NEW_SELECTION", query)
        
        arcpy.CopyFeatures_management("lyr", dest + i)
        print i + "copy successful"
    
    except:
        print i + arcpy.GetMessages(2)

