import urllib2
import os
import shutil
import urllib
import zipfile
import time
import sys
#This script will download zip files in the internet and place them into subfolders
#based on user input. it will create two folders in the download folder and unpack
#the data based on source

            
pathname = os.path.dirname(sys.argv[0])
root = pathname.split('/')[-1]
#List of COGCC Data
wells = "http://cogcc.state.co.us/Downloads/WELL_SHP.ZIP"
dirline = "http://cogcc.state.co.us/Downloads/DIRLINES.ZIP"
fac = "http://cogcc.state.co.us/Downloads/Fac_shp.zip"
permit = "http://cogcc.state.co.us/Downloads/PERMIT_S.ZIP"
bhl = "http://cogcc.state.co.us/Downloads/DIR_BHLS.ZIP"
COGCC = [permit, wells,dirline, fac, bhl]
#List of NDOCC Data
ND_Well = "https://www.dmr.nd.gov/output/ShapeFiles/Wells.zip"
ND_Rigs = "https://www.dmr.nd.gov/output/ShapeFiles/Rigs.zip"
ND_Directionals = "https://www.dmr.nd.gov/output/ShapeFiles/Directionals.zip"
ND_DIR_Lines = "https://www.dmr.nd.gov/output/ShapeFiles/Directionals_Lines.zip"
ND_Units = "https://www.dmr.nd.gov/output/ShapeFiles/UnitBoundaries.zip"
NDOCC = [ND_Well, ND_Rigs, ND_Directionals, ND_DIR_Lines, ND_Units]


print "This script will create two folders in the download folder and unpack the data based on source"
download_loc = raw_input("Download Folder: ")

#Function that will download zip files
def download(x, fol):
    file_name = x.split('/')[-1]
    u = urllib2.urlopen(x)
    f = open(file_name, 'wb')
    meta = u.info()
    file_size = int(meta.getheaders("Content-Length")[0])
    print "Downloading: %s Bytes: %s" % (file_name, file_size)

    file_size_dl = 0
    block_sz = 8192
    while True:
        buffer = u.read(block_sz)
        if not buffer:
            break

        file_size_dl += len(buffer)
        f.write(buffer)
        status = r"%10d  [%3.2f%%]" % (file_size_dl, file_size_dl * 100. / file_size)
        status = status + chr(8)*(len(status)+1)
        print status,

    f.close()
    
    
    if not os.path.isdir(download_loc + "\\" + "COGCC"):
       os.makedirs(download_loc + "\\" + "COGCC")
       COGCC = download_loc + "\\" + "COGCC"
    if not os.path.isdir(download_loc + "\\" + "NDCC"):
       os.makedirs(download_loc + "\\" + "NDCC")       
    zip = zipfile.ZipFile(root + '\\' + file_name)
    zip.extractall(fol)
    
    
#Exitcute function for COGCC
for x in COGCC:  
    download(x,download_loc + "\\" + "COGCC" )
print "COGCC Data Downloaded!"
#Exitcute function for NDCC
for x in NDOCC:
    download(x, download_loc + "\\" + "NDCC")
print "NDOGCC Data Downloaded!"




